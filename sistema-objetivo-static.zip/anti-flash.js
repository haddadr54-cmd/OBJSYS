// ANTI-FLASH ULTRA DIRETO
document.documentElement.style.cssText = 'background:linear-gradient(135deg,#f8fafc 0%,#e2e8f0 100%)!important;visibility:visible!important;opacity:1!important';

// CSS crítico inline
(document.head||document.documentElement).appendChild(Object.assign(document.createElement('style'),{
  textContent:'html,body,#root{background:linear-gradient(135deg,#f8fafc 0%,#e2e8f0 100%)!important;visibility:visible!important;opacity:1!important;margin:0;padding:0;min-height:100vh}*{visibility:visible!important;box-sizing:border-box}img{opacity:1!important;visibility:visible!important}'
}));