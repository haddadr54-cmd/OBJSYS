import{r as e}from"./index-CCr23udO.js";function f(){const[r,s]=e.useState(0),t=e.useCallback(()=>{s(a=>a+1)},[]);return{refreshKey:r,triggerRefresh:t}}export{f as u};
