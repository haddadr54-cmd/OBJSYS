# Sistema Objetivo Educacional - Deploy Discloud

Este é o pacote de deploy para o Discloud.

## Arquivos incluídos:
- dist/ - Aplicação React buildada
- index.js - Servidor Express
- package.json - Dependências de produção
- discloud.config - Configuração do Discloud

## Como usar:
1. Compacte todos os arquivos em um ZIP
2. Faça upload no painel do Discloud
3. O sistema estará disponível automaticamente

Versão: 2025-09-30T00:22:00.572Z
